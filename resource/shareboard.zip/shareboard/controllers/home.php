<?php
class Home extends Controller{
	protected function Index(){
		echo 'HOME/INDEX';
	}
}