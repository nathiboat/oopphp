<?php
class Users extends Controller{
	protected function Index(){
		echo 'USERS/INDEX';
	}
}