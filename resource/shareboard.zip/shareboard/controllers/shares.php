<?php
class Shares extends Controller{
	protected function Index(){
		echo 'SHARES/INDEX';
	}
}